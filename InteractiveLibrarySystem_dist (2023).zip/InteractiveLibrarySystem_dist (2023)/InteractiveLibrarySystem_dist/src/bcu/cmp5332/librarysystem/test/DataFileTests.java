package bcu.cmp5332.librarysystem.test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;

import org.junit.jupiter.api.Test;

class DataFileTests {

	@Test
	void testLoantxt() {
		File file = new File("./resources/data/loans.txt");
		assertTrue(file.exists());
	}

	@Test
	void testBooktxt() {
		File file = new File("./resources/data/books.txt");
		assertTrue(file.exists());
	}
	
	@Test
	void testPatrontxt() {
		File file = new File("./resources/data/patrons.txt");
		assertTrue(file.exists());
	}
}
