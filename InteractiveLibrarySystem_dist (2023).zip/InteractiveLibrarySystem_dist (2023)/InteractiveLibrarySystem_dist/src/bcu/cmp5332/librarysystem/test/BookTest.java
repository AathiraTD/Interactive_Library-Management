/**
 * 
 */
package bcu.cmp5332.librarysystem.test;

/**
 * 
 */
public class BookTest {

}
