/**
 * 
 */

package bcu.cmp5332.librarysystem.controllers;

public interface Controller {
    // This method will be used to execute various actions. You can expand it as needed.
    void executeAction(String actionCommand);
}
