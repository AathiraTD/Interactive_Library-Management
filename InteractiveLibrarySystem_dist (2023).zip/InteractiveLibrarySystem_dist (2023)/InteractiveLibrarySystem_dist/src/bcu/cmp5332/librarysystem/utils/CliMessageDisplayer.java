/**
 * 
 */
package bcu.cmp5332.librarysystem.utils;

/**
 * 
 */
public class CliMessageDisplayer implements MessageDisplayer {
    @Override
    public void displayMessage(String message) {
        System.out.println(message);
    }
}
